package com.chat;

public class Gentleman extends Customer{
    public Gentleman() {
        setSpeak(new guy());
    }
}
