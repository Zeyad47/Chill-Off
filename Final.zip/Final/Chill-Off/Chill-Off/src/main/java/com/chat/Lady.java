package com.chat;

public class Lady extends Customer{
    public Lady(){
        setSpeak(new gal());
    }
}