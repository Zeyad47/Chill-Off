package com.music.constant;
/**
 *
 * @author Huang Ruixin
 */

public class ToggleMusicConstant {

    public static final int LAST_ONE = 0;
    public static final int NEXT_ONE = 1;

}
