package com.light;

import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

public interface Command {

        public void execute(AnchorPane imageView);
}
