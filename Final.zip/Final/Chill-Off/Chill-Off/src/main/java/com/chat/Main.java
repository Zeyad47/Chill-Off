package com.chat;

import javax.swing.*;

public class Main extends JFrame {

    public static void main(String args[]){
        new Gentleman().performChat();
    }
}
