package com.music.constant;

/**
 *
 * @author Huang Ruixin
 */
public class RotateConstant {

    public static final int PLAY = 0;
    public static final int PAUSE = 1;
    public static final int STOP = 2;
    public static final int REPLAY = 3;
}
