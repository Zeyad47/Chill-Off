package com.chat;

interface Speak{
    public void chat();
}
