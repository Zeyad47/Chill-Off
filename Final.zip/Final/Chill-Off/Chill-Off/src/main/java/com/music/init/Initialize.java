package com.music.init;

import java.io.IOException;

/**
 *
 * @author Huang Ruixin
 */

public interface Initialize {

	 public void initialize()throws IOException;
}
